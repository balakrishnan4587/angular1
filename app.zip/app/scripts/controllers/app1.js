(function(){

	"use strict";
	
	var app = angular.module('myt1App',[
        'ap.lateralSlideMenu',
    ]);
	
	// service	
	app.service('number',  function() {
      return {
        isPositive: function(operationPrice) {
          return String(operationPrice).indexOf("-") == -1;
        }
      };
	});
	
})();