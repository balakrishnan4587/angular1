'use strict';
equipmentPointApp.service('AdminDataTempStore', ['$q', '$http', function($q, $http) {
    var myData = [];
    //console.log(usernameService.getData());
    //http://devtelewebsvc.hercrentals.com/Admin.svc/AdminEquipmentDetails?Division=HG&UserType=H&UserNbr=demoh10
    var promise = $http.get('json/GetAdminEquipmentList.json', { cache: 'true' }).success(function(data) {
        myData = data;
    });
    return {
        promise: promise,
        getData: function() {
            return myData;
        }
    };
}]);

equipmentPointApp.controller('adminequipmentsListCtrl', ['AdminDataTempStore', '$scope', function(AdminDataTempStore, $scope) {
    $scope.selected = 0;
    AdminDataTempStore.promise.then(function() {
        $scope.AdminEquiplists = AdminDataTempStore.getData().AdminEquipmentDetails;
        $scope.selected = AdminDataTempStore.getData().AdminEquipmentDetails[1];

    });

    $scope.select = function(index) {
        $scope.selected = index;
    };
	
    $scope.isActive = function(AdminEquiplist) {
        $scope.selected = AdminEquiplist;
    };
	
	// $scope.loadMore = function() {
            // var last = $scope.markers1[$scope.markers1.length - 1];
            // for (var i = 1; i <= 8; i++) {
                // $scope.markers1.push(last + i);
            // }
        // };
		
			$scope.pagination.currentPage = 0;
            $scope.initializeResultList();
            $scope.loadMoreCourses();
		
		$scope.pagination = { noOfPages: 1, currentPage: 0, pageSize: 15 };
        $scope.resultList = [];
		
		$scope.loadMoreCourses = function() {
            if ($scope.loadingResult) {
                return;
            }
            if ($scope.pagination.currentPage >= $scope.pagination.noOfPages) {
                return;
            }
            $scope.pagination.currentPage = $scope.pagination.currentPage + 1;
            $scope.offset = ($scope.pagination.currentPage - 1) * $scope.pagination.pageSize;
            $scope.limit = $scope.pagination.pageSize;
            $scope.loadingResult = true;

            var temp = $scope.AdminEquiplists.slice($scope.offset, $scope.offset + $scope.limit);
            for (var i = 0; i < temp.length; i++) {

                $scope.resultList.push(temp[i]);
            }

            $scope.loadingResult = false;
        };
        $scope.initializeResultList = function() {
            $scope.total = $scope.AdminEquiplists.length;
            $scope.pagination.noOfPages = Math.ceil($scope.AdminEquiplists.length / $scope.pagination.pageSize);


        };
        $scope.initializeResultList();
        $scope.loadMoreCourses();
}]);

equipmentPointApp.controller('EqAdminDetailCtrl', ['$scope', '$stateParams', 'AdminDataTempStore', '$location', '$state', '_', function($scope, $stateParams, AdminDataTempStore, $location, $state, _) {
    var Adminequipments = AdminDataTempStore.getData().AdminEquipmentDetails;
    var found = _.select(Adminequipments, function(node) {
        return node.equipIC === $stateParams.EqAdId;

    });
    $scope.AdminequipmentItem = found[0];
}]);
