'use strict';

 var IO = {
            //returns array with storable google.maps.Overlay-definitions
            IN: function(arr, //array with google.maps.Overlays
                encoded //boolean indicating if pathes should be stored encoded
            ) {
                var shapes = [],
                    shape, tmp;

                for (var i = 0; i < arr.length; i++) {
                    shape = arr[i];
                    tmp = { type: this.t_(shape.type), id: shape.id || null };

                    switch (tmp.type) {
                        case 'CIRCLE':
                            tmp.radius = shape.getRadius();
                            tmp.geometry = this.p_(shape.getCenter());
                            break;
                        case 'MARKER':
                            tmp.geometry = this.p_(shape.getPosition());
                            break;
                        case 'RECTANGLE':
                            tmp.geometry = this.b_(shape.getBounds());
                            break;
                        case 'POLYLINE':
                            tmp.geometry = this.l_(shape.getPath(), encoded);
                            break;
                        case 'POLYGON':
                            tmp.geometry = this.m_(shape.getPaths(), encoded);

                            break;
                    }
                    shapes.push(tmp);
                }

                return shapes;
            },
            //returns array with google.maps.Overlays
            OUT: function(arr, //array containg the stored shape-definitions
                map //map where to draw the shapes
            ) {
                var shapes = [],
                    goo = google.maps,
                    shape, tmp;

                for (var i = 0; i < arr.length; i++) {
                    shape = arr[i];

                    switch (shape.type) {
                        case 'CIRCLE':
                            tmp = new google.maps.Circle({
                                radius: Number(shape.radius),
                                center: this.pp_.apply(this, shape.geometry),
                                fillColor: '#ee9e8d',
                                strokeColor: '#ee6144',
                                strokeOpacity: 0.8,
                                strokeWeight: 2
                            });
                            break;
                        case 'MARKER':
                            tmp = new goo.Marker({ position: this.pp_.apply(this, shape.geometry) });
                            break;
                        case 'RECTANGLE':
                            tmp = new goo.Rectangle({ bounds: this.bb_.apply(this, shape.geometry) });
                            break;
                        case 'POLYLINE':
                            tmp = new goo.Polyline({ path: this.ll_(shape.geometry) });
                            break;
                        case 'POLYGON':
                            tmp = new goo.Polygon({ paths: this.mm_(shape.geometry) });

                            break;
                    }
                    tmp.setValues({ map: map, id: shape.id });
                    shapes.push(tmp);
                }
                return shapes;
            },
            l_: function(path, e) {
                path = (path.getArray) ? path.getArray() : path;
                if (e) {
                    return google.maps.geometry.encoding.encodePath(path);
                } else {
                    var r = [];
                    for (var i = 0; i < path.length; ++i) {
                        r.push(this.p_(path[i]));
                    }
                    return r;
                }
            },
            ll_: function(path) {
                if (typeof path === 'string') {
                    return google.maps.geometry.encoding.decodePath(path);
                } else {
                    var r = [];
                    for (var i = 0; i < path.length; ++i) {
                        r.push(this.pp_.apply(this, path[i]));
                    }
                    return r;
                }
            },

            m_: function(paths, e) {
                var r = [];
                paths = (paths.getArray) ? paths.getArray() : paths;
                for (var i = 0; i < paths.length; ++i) {
                    r.push(this.l_(paths[i], e));
                }
                return r;
            },
            mm_: function(paths) {
                var r = [];
                for (var i = 0; i < paths.length; ++i) {
                    r.push(this.ll_.call(this, paths[i]));

                }
                return r;
            },
            p_: function(latLng) {
                return ([latLng.lat(), latLng.lng()]);
            },
            pp_: function(lat, lng) {
                return new google.maps.LatLng(lat, lng);
            },
            b_: function(bounds) {
                return ([this.p_(bounds.getSouthWest()),
                    this.p_(bounds.getNorthEast())
                ]);
            },
            bb_: function(sw, ne) {
                return new google.maps.LatLngBounds(this.pp_.apply(this, sw),
                    this.pp_.apply(this, ne));
            },
            t_: function(s) {
                var t = ['CIRCLE', 'MARKER', 'RECTANGLE', 'POLYLINE', 'POLYGON'];
                for (var i = 0; i < t.length; ++i) {
                    if (s === google.maps.drawing.OverlayType[t[i]]) {
                        return t[i];
                    }
                }
            }

        };
        
function addYourLocationButton(map) {
    var controlDiv = document.createElement('div');
    var firstChild = document.createElement('button');
    firstChild.style.backgroundColor = '#fff';
    firstChild.style.border = 'none';
    firstChild.style.outline = 'none';
    firstChild.style.width = '28px';
    firstChild.style.height = '28px';
    firstChild.style.borderRadius = '2px';
    firstChild.style.boxShadow = '0 1px 4px rgba(0,0,0,0.3)';
    firstChild.style.cursor = 'pointer';
    firstChild.style.marginRight = '10px';
    firstChild.style.padding = '0';
    firstChild.title = 'Your Location';
    controlDiv.appendChild(firstChild);

    var secondChild = document.createElement('div');
    secondChild.style.margin = '5px';
    secondChild.style.width = '18px';
    secondChild.style.height = '18px';
    secondChild.style.backgroundImage = 'url(https://maps.gstatic.com/tactile/mylocation/mylocationsprite2x.png)';
    secondChild.style.backgroundSize = '180px 18px';
    secondChild.style.backgroundPosition = '0 0';
    secondChild.style.backgroundRepeat = 'norepeat';
    firstChild.appendChild(secondChild);

    google.maps.event.addListener(map, 'center_changed', function() {
        secondChild.style.backgroundPosition = '0 0';

    });
    var markerCurrentLocation;
    firstChild.addEventListener('click', function() {
        if (typeof(markerCurrentLocation) !== 'undefined') {
            markerCurrentLocation.setMap(null);
        }
        var imgX = '0',
            animationInterval = setInterval(function() {
                imgX = imgX === '18' ? '0' : '18';
                secondChild.style.backgroundPosition = imgX + 'px 0';
            }, 500);

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                map.setCenter(latLng);

                var markerCurrentLocation = new google.maps.Marker({
                    position: latLng,
                    map: map,
                    icon: 'images/icons/current-location.png'
                });
                markerCurrentLocation.setMap(map);

            });

        } else {
            clearInterval(animationInterval);
            secondChild.style.backgroundPosition = '0 0';
        }
    });

    controlDiv.index = 1;
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(controlDiv);
}

var boxText = document.createElement('div');
boxText.style.cssText = 'border: 1px solid black; margin-top: 8px; background: yellow; padding: 5px;';
google.maps.Marker.prototype.getCustomData = function(obj) {
    this.customData = obj;
};
google.maps.Marker.prototype.setCustomData = function(key, value) {
    if (typeof(this.customData) === 'undefined') {
        this.customData = {};
    }
    if (typeof(value) !== 'undefined') {
        this.customData[key] = value;
    } else {
        this.customData = key;
    }
};
equipmentPointApp.service('mapData', ['$q', '$http',function($q, $http) {
   
    var myData = null;
    //console.log(usernameService.getData());
    //'http://devtelewebsvc.hercrentals.com/Equipment.svc/EquipmentList_ForDemo?Division=HG&UserType=H&UserNbr='+usernameService.getData()
    var promise = $http.get('scripts/map/EquipmentList_1000.json', { cache: 'true' }).success(function(data) {
        myData = data;
    });
    return {
        promise: promise,
        getData: function() {
            return myData;
        }
    };
}]);
equipmentPointApp.controller('DirectionCtrl', ['$q', 'NgMap', 'mapDataTempStore', '$interpolate', '$sce', '$templateRequest', '$scope', '$timeout', '$state', '$rootScope', '$uibModalInstance', 'eqDetails', function($q, NgMap, mapDataTempStore, $interpolate, $sce, $templateRequest, $scope, $timeout, $state, $rootScope, $uibModalInstance, eqDetails) {


    $scope.init = function() {

        $scope.render = true;

        $scope.$on('mapInitialized', function(evt, map) {

            addYourLocationButton(map);
            $scope.toggle = function() {
                $scope.toggleSide = !$scope.toggleSide;
                $timeout(function() {
                    google.maps.event.trigger(map, 'resize');
                }, 1000);

            };
            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            };

            var autocompleteFrom = new google.maps.places.Autocomplete(document.getElementById('dirSource'));
            var autocompleteTo = new google.maps.places.Autocomplete(document.getElementById('dirDestination'));

            var fetchAddress = function(p) {
                var Position = new google.maps.LatLng(p.coords.latitude, p.coords.longitude),
                    Locater = new google.maps.Geocoder();

                Locater.geocode({ 'latLng': Position }, function(results, status) {
                    if (status === google.maps.GeocoderStatus.OK) {
                        var _r = results[0];
                        $timeout(function() {
                            // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
                            $scope.inputField = _r.formatted_address;
                        });
                    } else if (status === google.maps.GeocoderStatus.NOT_FOUND) {

                    } else if (status === google.maps.GeocoderStatus.ZERO_RESULTS) {

                    }
                });
            };

            $scope.useGPS = function() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        fetchAddress(position, $scope.originn);
                    });
                }

            };

            google.maps.event.addListener(autocompleteFrom, 'place_changed', function() {
                var placeFrom = autocompleteFrom.getPlace();
                // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
                $scope.originn = placeFrom.formatted_address;
            });

            google.maps.event.addListener(autocompleteTo, 'place_changed', function() {

                var placeTo = autocompleteTo.getPlace();
                // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
                $scope.destinationn = placeTo.formatted_address;
            });

            $scope.calcRoute = function() {
                if ((typeof($scope.originn) === 'undefined') || ($scope.originn === '')) {

                    if (navigator.geolocation) {

                        navigator.geolocation.getCurrentPosition(function(position) {

                            var Position = new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                Locater = new google.maps.Geocoder();

                            Locater.geocode({ 'latLng': Position }, function(results, status) {
                                if (status === google.maps.GeocoderStatus.OK) {

                                    var _r = results[0];
                                    $timeout(function() {

                                        $scope.originn = _r.formatted_address;

                                    });
                                }
                            });
                        });
                    }
                } else {
                    $rootScope.originn = $scope.originn;
                }

                if ((typeof($scope.destinationn) === 'undefined') || ($scope.destinationn === '')) {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {

                            var Position = new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
                                Locater = new google.maps.Geocoder();

                            Locater.geocode({ 'latLng': Position }, function(results, status) {
                                if (status === google.maps.GeocoderStatus.OK) {
                                    var _r = results[0];
                                    $timeout(function() {
                                        $scope.destinationn = _r.formatted_address;

                                    });
                                }
                            });
                        });
                    }
                } else {
                    $rootScope.destinationn = $scope.destinationn;
                }

                var myWatcher = $scope.$watch('[originn,destinationn]', function() {

                    if ((typeof($scope.originn) !== 'undefined') && ($scope.originn !== '') && (typeof($scope.destinationn) !== 'undefined') && ($scope.destinationn !== '')) {

                        $rootScope.originn = $scope.originn;
                        $rootScope.destinationn = $scope.destinationn;

                        map.directionsRenderers[0].setMap(map);
                        $scope.origin = $rootScope.originn;
                        $scope.destination = $rootScope.destinationn;

                        myWatcher();
                    }
                });
            };

            var alerts;
            if (eqDetails.Alert > 0) {
                alerts = eqDetails.Alert;
            } else { alerts = ''; }

            var marker = null;
            if (eqDetails.Alert > 0) {
                marker = new MarkerWithLabel({
                    position: eqDetails.position,
                    map: map,
                    labelContent: alerts,
                    labelClass: 'labels1',
                    labelStyle: {
                        opacity: 0.75
                    },
                    icon: eqDetails.icon
                });
            } else {
                marker = new google.maps.Marker({
                    position: eqDetails.position,
                    map: map,
                    icon: eqDetails.icon
                });
            }

            marker.setMap(map);
            var Locater = new google.maps.Geocoder();
            Locater.geocode({ 'latLng': marker.getPosition() }, function(results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                    var _r = results[0];
                    $timeout(function() {
                        $scope.destinationn = _r.formatted_address;

                    });
                }
            });

            $timeout(function() {
                $scope.calcRoute();
            }, 1000);

            $scope.swap = function() {
                var temp = '',
                    temp1 = '';

                temp = $scope.originn;
                temp1 = $scope.destinationn;

                $scope.originn = temp1;
                $scope.destinationn = temp;
            };
        });
    };

}]);


equipmentPointApp.service('mapDataTempStore', ['mapData', '$q', 'cfpLoadingBar', function(mapData, $q, cfpLoadingBar) {
    var myData = null;
    return {
        getAllData: function() {
            var defer;
            defer = $q.defer();
            cfpLoadingBar.start();
            cfpLoadingBar.inc();
            mapData.promise.then(function() {
                var markers = mapData.getData();
                defer.resolve(markers);
                cfpLoadingBar.complete();

            });
            return defer.promise;
        },
        getMapData: function() {
            return myData;
        },
        setMapData: function(data) {
            myData = data;
        }
    };
}]);



equipmentPointApp.controller('ModalInstanceCtrl', ['$scope', '$uibModalInstance', 'availableEquipmentTypes', 'availableStatuses', 'availableIgnitions', 'availableBranchesMine', 'availableBranchesAll', 'currentSelections', function($scope, $uibModalInstance, availableEquipmentTypes, availableStatuses, availableIgnitions, availableBranchesMine, availableBranchesAll, currentSelections) {
    $scope.dropdownSettingsEquipmenttype = {
        imgIconFolder: 'equipmentlist',
        imgPrefix: 'eqtype',
        scrollableHeight: '200px',
        scrollable: true,
        enableSearch: true,
    };
    $scope.dropdownSettingsStatus = {
        imgIconFolder: 'status',
        imgPrefix: 'status',
        scrollableHeight: '200px',
        scrollable: true,
        enableSearch: true,
    };
    $scope.dropdownSettingsIgnition = {
        imgIconFolder: 'ignition',
        imgPrefix: 'ignition',
        scrollableHeight: '200px',
        scrollable: true,
        enableSearch: true,
    };
    $scope.dropdownSettingsBranches = {
        imgIconFolder: 'ignition',
        imgPrefix: 'ignition',
        scrollableHeight: '200px',
        scrollable: true,
        enableSearch: true,
    };
    $scope.extraSettings = { displayProp: 'id' };
    $scope.selectedEquipmentTypes = currentSelections.selectedEquipmentTypes || [];
    $scope.selectedStatuses = currentSelections.selectedStatuses || [];
    $scope.selectedIgnitions = currentSelections.selectedIgnitions || [];
    $scope.selectedBranchesMine = currentSelections.selectedBranchesMine || [];
    $scope.selectedBranchesAll = currentSelections.selectedBranchesAll || [];
    $scope.availableEquipmentTypes = availableEquipmentTypes;
    $scope.availableStatuses = availableStatuses;
    $scope.availableIgnitions = availableIgnitions;
    $scope.availableBranchesMine = availableBranchesMine;
    $scope.availableBranchesAll = availableBranchesAll;


    var selections = {};
    selections.selectedEquipmentTypes = $scope.selectedEquipmentTypes;
    selections.selectedStatuses = $scope.selectedStatuses;
    selections.selectedIgnitions = $scope.selectedIgnitions;
    selections.selectedBranchesMine = $scope.selectedBranchesMine;
    selections.selectedBranchesAll = $scope.selectedBranchesAll;

    $scope.ok = function() {
        $uibModalInstance.close(selections);
    };
    $scope.cancel = function() {
        $uibModalInstance.dismiss('cancel');
    };
}]);
equipmentPointApp.controller('equipmentsListCtrl', ['mapDataTempStore', '$scope', '$rootScope', 'NgMap', '$state', '$stateParams', '_', '$document', '$window', '$uibModal', '$sce', 'cfpLoadingBar', function(mapDataTempStore, $scope, $rootScope, NgMap, $state, $stateParams, _, $document, $window, $uibModal, $sce, cfpLoadingBar) {
    $scope.$on('filter', function(data) {
        $scope.checkEqID = function(value) {
            return value.EqIC && data.indexOf(value.EqIC) !== -1;
        };
        $scope.markers = data.equipments;
    });
    $scope.selected = null;
    var states = ['in Equipment Id', 'in Contract Number', 'in Branch Id', 'in Account No'];
    $scope.states = states;
    $scope.searchValue = undefined;
    $scope.select = function(index) {
        $scope.selected = index;	
    };
    mapDataTempStore.getAllData().then(function(data) {
        var totalAlerts = 0;
        for (var item = 0; item < data.equipments.length; item++) {
            totalAlerts += data.equipments[item].Alert;
        }

        $scope.loadMore = function() {
            var last = $scope.markers1[$scope.markers1.length - 1];
            for (var i = 1; i <= 8; i++) {
                $scope.markers1.push(last + i);
            }
        };


        $rootScope.totalAlerts = totalAlerts;
        cfpLoadingBar.start();
        cfpLoadingBar.inc();

        $scope.trustAsHtml = function(string) {
            return $sce.trustAsHtml(string.toString());
        };
        $scope.clearSearch = function() {
            $scope.searchValue = '';
            var element = $window.document.getElementById('equipmentSearch');
            if (element) {
                element.focus();
            }
            $scope.searchEquipments();
        };

        $scope.searchEquipments = function() {
            cfpLoadingBar.start();
            cfpLoadingBar.inc();
            if (!String.prototype.splice) {
                /**
                 * {JSDoc}
                 *
                 * The splice() method changes the content of a string by removing a range of
                 * characters and/or adding new characters.
                 *
                 * @this {String}
                 * @param {number} start Index at which to start changing the string.
                 * @param {number} delCount An integer indicating the number of old chars to remove.
                 * @param {string} newSubStr The String that is spliced in.
                 * @return {string} A new string with the spliced substring.
                 */
                String.prototype.splice = function(start, delCount, newSubStr) {
                    return this.slice(0, start) + newSubStr + this.slice(start + Math.abs(delCount));
                };
            }

            var found = null,
                query;
            for (var state = 0; state < states.length; state++) {
                if (typeof($scope.searchValue) !== 'undefined' && $scope.searchValue.indexOf(states[state]) !== -1) {
                    found = states[state];
                    query = $scope.searchValue.replace(states[state], '').trim();
                    break;
                }
            }
            var filterField = '';
            switch (found) {
                case 'in Equipment Id':
                    filterField = 'EqIC';
                    break;
                case 'in Contract Number':
                    filterField = 'Cont';
                    break;
                case 'in Branch Id':
                    filterField = 'Bran';
                    break;
                case 'in Account No':
                    filterField = 'Acc';
                    break;
            }
            if (query === undefined) {
                if (typeof($scope.searchValue) !== 'undefined') {
                    query = $scope.searchValue.trim();
                } else {
                    query = 0;
                }
            }
            if (typeof($scope.filterMarkers) !== 'undefined') { $scope.searchMarkers = angular.copy($scope.filterMarkers); } else if (typeof($scope.listFromMap) !== 'undefined') { $scope.searchMarkers = $scope.listFromMap; } else { $scope.searchMarkers = angular.copy(data.equipments); }
            if (query.length > 0) {

                var searchTemp = [];
                for (var item = 0; item < $scope.searchMarkers.length; item++) {
                    var tempItem = angular.copy($scope.searchMarkers[item]);
                    var propertyValue = '';
                    if (filterField !== '') {
                        if ($scope.searchMarkers[item][filterField].indexOf(query) !== -1) {
                            propertyValue = tempItem[filterField];

                            propertyValue = propertyValue.splice(propertyValue.indexOf(query), 0, '<span style="color:red">');
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query) + query.length, 0, '</span>');

                            if (filterField === 'EqIC') {

                                tempItem.eqICTemp = propertyValue;
                            } else {

                                tempItem[filterField] = propertyValue;
                            }

                            searchTemp.push(tempItem);

                        }
                    } else {

                        var matchCount = 0;
                        if ($scope.searchMarkers[item].EqIC.indexOf(query) !== -1) {

                            propertyValue = tempItem.EqIC;
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query), 0, '<span style="color:red">');
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query) + query.length, 0, '</span>');

                            tempItem.eqICTemp = propertyValue;

                            matchCount++;
                        }
                        if ($scope.searchMarkers[item].Cont.indexOf(query) !== -1) {
                            propertyValue = tempItem.Cont;
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query), 0, '<span style="color:red">');
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query) + query.length, 0, '</span>');
                            tempItem.Cont = propertyValue;
                            matchCount++;
                        }
                        if ($scope.searchMarkers[item].Bran.indexOf(query) !== -1) {
                            propertyValue = tempItem.Bran;
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query), 0, '<span style="color:red">');
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query) + query.length, 0, '</span>');
                            tempItem.Bran = propertyValue;
                            matchCount++;
                        }
                        if ($scope.searchMarkers[item].Acc.indexOf(query) !== -1) {
                            propertyValue = tempItem.Acc;
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query), 0, '<span style="color:red">');
                            propertyValue = propertyValue.splice(propertyValue.indexOf(query) + query.length, 0, '</span>');
                            tempItem.Acc = propertyValue;
                            matchCount++;
                        }
                        if (matchCount > 0) {
                            searchTemp.push(tempItem);

                        }
                    }
                }

                $scope.markers = searchTemp;

            } else {
                $scope.markers = $scope.filterMarkers;
                if (typeof($scope.filterMarkers) !== 'undefined') { $scope.markers = $scope.filterMarkers; } else if (typeof($scope.listFromMap) !== 'undefined') { $scope.markers = $scope.listFromMap; } else { $scope.markers = angular.copy(data.equipments); }
            }

            $scope.resultList = [];
            $scope.pagination.currentPage = 0;
            $scope.initializeResultList();
            $scope.loadMoreCourses();
            cfpLoadingBar.complete();
        };
        $scope.filterFromMapEqids = [];



        $scope.pagination = { noOfPages: 1, currentPage: 0, pageSize: 15 };
        $scope.resultList = [];





        $scope.markers = data.equipments;

        $scope.loadMoreCourses = function() {
            if ($scope.loadingResult) {
                return;
            }
            if ($scope.pagination.currentPage >= $scope.pagination.noOfPages) {
                return;
            }
            $scope.pagination.currentPage = $scope.pagination.currentPage + 1;
            $scope.offset = ($scope.pagination.currentPage - 1) * $scope.pagination.pageSize;
            $scope.limit = $scope.pagination.pageSize;
            $scope.loadingResult = true;

            var temp = $scope.markers.slice($scope.offset, $scope.offset + $scope.limit);
            for (var i = 0; i < temp.length; i++) {

                $scope.resultList.push(temp[i]);
            }

            $scope.loadingResult = false;
        };
        $scope.initializeResultList = function() {
            $scope.total = $scope.markers.length;
            $scope.pagination.noOfPages = Math.ceil($scope.markers.length / $scope.pagination.pageSize);


        };
        $scope.initializeResultList();
        $scope.loadMoreCourses();


        $scope.availableEquipmentTypes = [{
            'label': 'All',
            'id': 0
        }, {
            'label': 'Aerial',
            'id': 1
        }, {
            'label': 'Aerial Equipment',
            'id': 2
        }, {
            'label': 'Air Equipment',
            'id': 3
        }, {
            'label': 'Compaction & Paving Equipment',
            'id': 4
        }, {
            'label': 'Concrete & Masonry Equipment',
            'id': 5
        }, {
            'label': 'Earthmoving Equipment',
            'id': 6
        }, {
            'label': 'Electrical Tools & Equipment',
            'id': 7
        }, {
            'label': 'General',
            'id': 8
        }, {
            'label': 'General Equipment',
            'id': 9
        }, {
            'label': 'Generators',
            'id': 10
        }, {
            'label': 'Lawn & Garden Equipment',
            'id': 11
        }, {
            'label': 'Material Handling Equipment',
            'id': 12
        }, {
            'label': 'Pumping Equipment',
            'id': 13
        }, {
            'label': 'Safety Equipment',
            'id': 14
        }, {
            'label': 'Trucks & Trailers',
            'id': 15
        }];
        $scope.availableStatuses = [{
            'label': 'All',
            'id': 0
        }, {
            'label': 'Hertz Owned',
            'id': 1
        }, {
            'label': 'Customer Owned',
            'id': 2
        }, {
            'label': 'ON Rent',
            'id': 3
        }, {
            'label': 'OFF Rent',
            'id': 4
        }, {
            'label': 'NOT Reporting',
            'id': 5
        }, {
            'label': 'For PickUp',
            'id': 6
        }];
        $scope.availableIgnitions = [{
            'label': 'OFF',
            'id': 0
        }, {
            'label': 'ON',
            'id': 1
        }, {
            'label': 'Not Reporting',
            'id': 2
        }];
        $scope.availableBranchesMine = [{
            'label': 'All',
            'id': 0
        }, {
            'label': '9418',
            'id': 9418
        }, {
            'label': '9708',
            'id': 9708
        }];
        $scope.availableBranchesAll = [{
            'label': 'All',
            'id': 0
        }, {
            'label': '9418',
            'id': 9418
        }, {
            'label': '9708',
            'id': 9708
        }];

        $scope.$on('clusterList', function(event, list) {
            $scope.filterFromMapEqids = list;
            var temp = [];
            for (var item = 0; item < data.equipments.length; item++) {
                if ($scope.filterFromMapEqids.length > 0 && ($scope.filterFromMapEqids.indexOf(data.equipments[item].EqIC) !== -1)) {
                    temp.push(data.equipments[item]);
                }
            }
            $scope.markers = temp;
            $scope.listFromMap = temp;
            $scope.resultList = [];
            $scope.pagination.currentPage = 0;
            $scope.initializeResultList();
            $scope.loadMoreCourses();
        });
        if ($stateParams.EqIds !== undefined) {

            $scope.filterFromMapEqids = $stateParams.EqIds;
            var temp = [];
            for (var item1 = 0; item1 < data.equipments.length; item1++) {
                if ($scope.filterFromMapEqids.length > 0 && ($scope.filterFromMapEqids.indexOf(data.equipments[item1].EqIC) !== -1)) {
                    temp.push(data.equipments[item1]);
                }
            }
            $scope.markers = temp;
        } else {
            $scope.filteredEquipmentTypes = $scope.availableEquipmentTypes;
            $scope.filteredStatuses = $scope.availableStatuses;
            $scope.filteredIgnitions = $scope.availableIgnitions;
            $scope.filteredBranchesMine = $scope.availableBranchesMine;
            $scope.filteredBranchesAll = $scope.availableBranchesAll;
        }
        $scope.currentSelections = {};
        $scope.openModel = function() {
            var modalInstance = $uibModal.open({
                templateUrl: 'views/filtermodel.html',
                backdrop: false,
                animation: true,
                controller: 'ModalInstanceCtrl',
                resolve: {
                    availableEquipmentTypes: function() {
                        return $scope.availableEquipmentTypes;
                    },
                    availableStatuses: function() {
                        return $scope.availableStatuses;
                    },
                    availableIgnitions: function() {
                        return $scope.availableIgnitions;
                    },
                    availableBranchesMine: function() {
                        return $scope.availableBranchesMine;
                    },
                    availableBranchesAll: function() {
                        return $scope.availableBranchesAll;
                    },
                    currentSelections: function() {
                        return $scope.currentSelections;
                    }
                }
            });
            modalInstance.result.then(function(selectedItems) {
                $scope.currentPage = 0;
                $scope.currentSelections = selectedItems;
                $scope.name = selectedItems;
                $scope.filterFromMapEqids = undefined;
                $scope.filteredEquipmentTypes = selectedItems.selectedEquipmentTypes;

                $scope.filteredStatuses = selectedItems.selectedStatuses;
                $scope.filteredIgnitions = selectedItems.selectedIgnitions;
                $scope.filteredBranchesMine = selectedItems.selectedBranchesMine;
                $scope.filteredBranchesAll = selectedItems.selectedBranchesAll;
                var filteredEquipmentTypeIds = [];
                _.each($scope.filteredEquipmentTypes, function(bb) { filteredEquipmentTypeIds.push(bb.id); });
                var filteredBranchIdsMine = [];
                _.each($scope.filteredBranchesMine, function(bb) { filteredBranchIdsMine.push(bb.id); });
                var filteredBranchIdsAll = [];
                _.each($scope.filteredBranchesAll, function(bb) { filteredBranchIdsAll.push(bb.id); });
                if (filteredBranchIdsMine[0] === 0) {
                    _.each($scope.availableBranchesMine, function(bb) { filteredBranchIdsMine.push(bb.id); });
                }
                if (filteredBranchIdsAll[0] === 0) {
                    _.each($scope.availableBranchesAll, function(bb) { filteredBranchIdsAll.push(bb.id); });
                }
                var filteredStatusIds = [];
                _.each($scope.filteredStatuses, function(bb) { filteredStatusIds.push(bb.id); });
                if (filteredEquipmentTypeIds[0] === 0) {
                    _.each($scope.availableEquipmentTypes, function(bb) { filteredEquipmentTypeIds.push(bb.id); });
                }
                if (filteredStatusIds[0] === 0) {
                    _.each($scope.availableStatuses, function(bb) { filteredStatusIds.push(bb.id); });
                }
                var filteredIgnitionIds = [];
                _.each($scope.filteredIgnitions, function(bb) { filteredIgnitionIds.push(bb.id); });
                var temp = [];
                for (var item = 0; item < data.equipments.length; item++) {

                    if (
                        ((filteredBranchIdsMine.length > 0 && (filteredBranchIdsMine.indexOf(data.equipments[item].Bran) !== -1)) || (filteredBranchIdsMine.length === 0 && true)) &&
                        ((filteredBranchIdsAll.length > 0 && (filteredBranchIdsAll.indexOf(data.equipments[item].Bran) !== -1)) || (filteredBranchIdsAll.length === 0 && true)) &&
                        ((filteredEquipmentTypeIds.length > 0 && (filteredEquipmentTypeIds.indexOf(data.equipments[item].EqType) !== -1)) || ((filteredEquipmentTypeIds.length === 0) && true)) &&
                        ((filteredStatusIds.length > 0 && (filteredStatusIds.indexOf(data.equipments[item].Status) !== -1)) || ((filteredStatusIds.length === 0) && true)) &&
                        ((filteredIgnitionIds.length > 0 && (filteredIgnitionIds.indexOf(data.equipments[item].IGNITION) !== -1)) || ((filteredIgnitionIds.length === 0) && true))
                    ) {
                        temp.push(data.equipments[item]);
                    }
                }
                $scope.markers = temp;
                $scope.filterMarkers = temp;
                $scope.resultList = [];
                $scope.pagination.currentPage = 0;
                $scope.initializeResultList();
                $scope.loadMoreCourses();
                mapDataTempStore.setMapData({ 'equipments': temp });
                if (temp.length === 0) {
                    cfpLoadingBar.complete();
                }

                $rootScope.$broadcast('redraw');
            }, function() { cfpLoadingBar.complete(); });
        };

        $scope.sel = function(index) {
            $scope.selected = index;
        };

        cfpLoadingBar.complete();

        if ($stateParams.EqIds !== undefined) {
            //  cfpLoadingBar.complete();
        }
    });
}]);

equipmentPointApp.controller('MapCtrl', ['$q', 'NgMap', 'mapDataTempStore', '$interpolate', '$sce', '$templateRequest', '$scope', '$timeout', '$state', '$rootScope', '$stateParams', '_', 'cfpLoadingBar', '$uibModal', function($q, NgMap, mapDataTempStore, $interpolate, $sce, $templateRequest, $scope, $timeout, $state, $rootScope, $stateParams, _, cfpLoadingBar, $uibModal) {
    var vm = this;
	/* $scope.convert= function(param){
	console.log(param);
	var colorCode;
	if(param=="ON Rent"){
		colorCode='#000000'; 
	}else if(param=="OFF Rent"){
		colorCode='#000000'; 
	}else if(param=="Hertz Owned"){
		colorCode='#000000'; 
	}
	return colorCode;
	} */
    function init() {
        cfpLoadingBar.start();
        cfpLoadingBar.inc();
        vm.dynMarkers = [];
        $scope.mapIdle = function() {};


        NgMap.getMap().then(function(map) {
            vm.map = map;
            $scope.clearmarker = function() {
                vm.map.directionsRenderers[0].setMap(null);
            };
            $scope.loadEquipmentList = function(eqIds) {
                $rootScope.$broadcast('clusterList', eqIds);
            };
            $scope.$on('routemap', function() {
                vm.map.directionsRenderers[0].setMap(map);
                $scope.origin = $rootScope.originn;
                $scope.destination = $rootScope.destinationn;
                $rootScope.originn = undefined;
                $rootScope.destinationn = undefined;
            });
            var markers = [];
            markers = mapDataTempStore.getMapData().equipments;

            if (typeof($stateParams.mapLink) === 'undefined') {

                var centerControlDiv = document.createElement('div');
                // var centerControl = new CenterControl(centerControlDiv, map);
                centerControlDiv.index = 1;
                map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(centerControlDiv);
            }

            function attachMarkerEvent(marker) {
                google.maps.event.addListener(marker, 'click', function() {

                    $scope.vm = marker;
                    $scope.customData = angular.copy(marker.customData);
                    $scope.customData.position = angular.copy(marker.getPosition());
                    $scope.customData.icon = angular.copy(marker.getIcon());

                    map.showInfoWindow('marker_window', marker);
                });
            }
            for (var i = 0; i < markers.length; i++) {

                var latLng = new google.maps.LatLng(markers[i].Lat, markers[i].Long);
                var alerts;
                if (markers[i].Alert > 0) {
                    alerts = markers[i].Alert;
                } else { alerts = ''; }


                var marker = null;
                if (markers[i].Alert > 0) {
                    marker = new MarkerWithLabel({
                        position: latLng,
                        map: map,
                        labelContent: alerts,
                        labelClass: 'labels1',
                        labelStyle: {
                            opacity: 0.75
                        },
                        icon: 'images/icons/markericons/eqicon_' + markers[i].EqType + '_alert.png'
                    });
                } else {
                    marker = new google.maps.Marker({
                        position: latLng,
                        map: map,
                        icon: 'images/icons/markericons/eqicon_' + markers[i].EqType + '.png'
                    });
                }


                marker.setCustomData('EqIC', markers[i].EqIC);
                marker.setCustomData('Desc', markers[i].Desc);
                marker.setCustomData('Bran', markers[i].Bran);
                marker.setCustomData('EqIC', markers[i].EqIC);
                marker.setCustomData('Cont', markers[i].Cont);
                marker.setCustomData('Acc', markers[i].Acc);
                marker.setCustomData('Status', markers[i].Status);
                marker.setCustomData('Alert', markers[i].Alert);
                marker.setCustomData('IGNITION', markers[i].IGNITION);
                marker.setCustomData('EqType', markers[i].EqType);
                google.maps.event.addListener(map, 'zoom_changed', function() {});
                attachMarkerEvent(marker);
                vm.dynMarkers.push(marker);
            }
            if (typeof(vm.markerClusterer) !== 'undefined') {
                vm.markerClusterer.clearMarkers();
                vm.markerClusterer = null;
                map.hideInfoWindow('cluster_window');
                map.hideInfoWindow('marker_window');
                map.setZoom(3);
                var nw = new google.maps.LatLng(
                    41.850033, -87.6500523
                );
                map.setCenter(nw);
            }

            vm.markerClusterer = new MarkerClusterer(map, vm.dynMarkers, {});

            google.maps.event.addListener(map, 'click', function() {
                map.hideInfoWindow('cluster_window');
                map.hideInfoWindow('marker_window');
            });
            google.maps.event.addListener(vm.markerClusterer, 'click', function() {
                map.hideInfoWindow('cluster_window');
            });
            google.maps.event.addListener(vm.markerClusterer, 'click', function(c) {
                $scope.availableEquipmentTypes = [{
                    'label': 'All',
                    'id': 0
                }, {
                    'label': 'Aerial',
                    'id': 1
                }, {
                    'label': 'Aerial Equipment',
                    'id': 2
                }, {
                    'label': 'Air Equipment',
                    'id': 3
                }, {
                    'label': 'Compaction & Paving Equipment',
                    'id': 4
                }, {
                    'label': 'Concrete & Masonry Equipment',
                    'id': 5
                }, {
                    'label': 'Earthmoving Equipment',
                    'id': 6
                }, {
                    'label': 'Electrical Tools & Equipment',
                    'id': 7
                }, {
                    'label': 'General',
                    'id': 8
                }, {
                    'label': 'General Equipment',
                    'id': 9
                }, {
                    'label': 'Generators',
                    'id': 10
                }, {
                    'label': 'Lawn & Garden Equipment',
                    'id': 11
                }, {
                    'label': 'Material Handling Equipment',
                    'id': 12
                }, {
                    'label': 'Pumping Equipment',
                    'id': 13
                }, {
                    'label': 'Safety Equipment',
                    'id': 14
                }, {
                    'label': 'Trucks & Trailers',
                    'id': 15
                }];
                $scope.availableStatuses = [{
                    'label': 'All',
                    'id': 0
                }, {
                    'label': 'Hertz Owned',
                    'id': 1
                }, {
                    'label': 'Customer Owned',
                    'id': 2
                }, {
                    'label': 'ON Rent',
                    'id': 3
                }, {
                    'label': 'OFF Rent',
                    'id': 4
                }, {
                    'label': 'NOT Reporting',
                    'id': 5
                }, {
                    'label': 'For PickUp',
                    'id': 6
                }];
                $scope.availableIgnitions = [{
                    'label': 'OFF',
                    'id': 0
                }, {
                    'label': 'ON',
                    'id': 1
                }, {
                    'label': 'Not Reporting',
                    'id': 2
                }];
                var filteredEquipmentTypeIds = [];
                _.each($scope.availableEquipmentTypes, function(bb, index) { filteredEquipmentTypeIds[index] = bb.label; });
                var filteredStatusIds = [];
                _.each($scope.availableStatuses, function(bb, index) { filteredStatusIds[index] = bb.label; });
                var filteredIgnitionIds = [];
                _.each($scope.availableIgnitions, function(bb, index) { filteredIgnitionIds[index] = bb.label; });
                var counters = c.getCount();
                var text = [];
                var total = [];
                var details = [];
                for (var i = 0; i < counters.ess.length; i++) {
                    var temptext = '';
                    if (typeof(counters.ess[i]) !== 'undefined') {
                        temptext += 'Type: ' + filteredEquipmentTypeIds[i];
                        var temp = {};
                        temp.equipmentStatus = filteredStatusIds[i];
                        temp.ignition = [];
                        var tot = 0;
                        var temptext1 = '';
                        for (var y = 0; y < $scope.availableIgnitions.length; y++) {
                            temp.ignition[y] = {};
                            temp.ignition[y].name = filteredIgnitionIds[y];
                            temp.ignition[y].count = counters.ess[i][y] || 0;
                            tot += temp.ignition[y].count;
                        }
                        temp.total = tot;
                        details.push(temp);
                        temptext += ' Total: ' + tot + ' ' + temptext1;
                        temptext += '<br/>';
                        temptext += '<a href="#" onclick="filterlist(' + counters.eqIds + ')">View alert </a>';
                        text[i] = temptext;
                        total[i] = tot;
                    }
                    $scope.alertCount = counters.eqIds;

                }

                $scope.eqIds = counters.eqIds;
                $scope.alertCount = counters.alertCount;
                $scope.alertcountEquipment = counters.alertcountEq;
                $scope.details = details;
                map.showInfoWindow('cluster_window', c.getCenter());
            });
            google.maps.event.addListener(vm.markerClusterer, 'mouseout', function() {});
            google.maps.event.addListener(map, 'zoom_changed', function() {
                map.hideInfoWindow('cluster_window');
                map.hideInfoWindow('marker_window');

            });
            google.maps.event.addListener(vm.markerClusterer, 'clusteringbegin', function() {});

            google.maps.event.addListener(vm.markerClusterer, 'clusteringend', function() {
                cfpLoadingBar.complete();
            });

            $scope.$on('resizemap', function() {
                $timeout(function() {
                    map.hideInfoWindow('cluster_window');
                    map.hideInfoWindow('marker_window');
                    google.maps.event.trigger(map, 'resize');

                }, 1000);

            });

            $scope.openDirections = function(eqDetails) {

                var modalInstanceDirections = $uibModal.open({
                    templateUrl: 'views/directionpanel.html',
                    backdrop: false,
                    scope: $scope,
                    controller: 'DirectionCtrl',
                    animation: false,
                    windowTopClass: 'directionWindow',
                    appendTo: angular.element(document.querySelector('#wrapperInner')),

                    resolve: {
                        eqDetails: function() {
                            return eqDetails;
                        }
                    }
                });
                modalInstanceDirections.result.then(function() {

                }, function() {});
            };



        });

    }
    mapDataTempStore.getAllData().then(function(data) {
        mapDataTempStore.setMapData(data);
        init();
    });
    $scope.$on('redraw', function() {
        init();
    });
}]);
equipmentPointApp.controller('MainCtrl', ['$q', 'NgMap', 'mapDataTempStore', '$interpolate', '$sce', '$templateRequest', '$scope', '$rootScope', '$state', function($q, NgMap, mapDataTempStore, $interpolate, $sce, $templateRequest, $scope, $rootScope, $state) {
			$scope.menuhide = function() {
						var myEl = angular.element( document.querySelector( 'body' ) )
						myEl.removeClass('lateral-slide-menu-in-transition'); 
						myEl.removeClass('lateral-slide-menu-is-open'); 
					};
    $scope.state = $state;
    $scope.navMenu = [
        { title: 'Dashboard', link: 'dashboard', 'reloadRequired': 'reload:false', img: 'images/icons/db_inact_icon.png' },
        { title: 'equipment', link: 'home.main', 'reloadRequired': 'reload:true', img: 'images/icons/equipment_inact_icon.png' },
        { title: 'Reports', link: 'reports', 'reloadRequired': 'reload:false', img: 'images/icons/report_inact_icon.png' },
        { title: 'geo fence', link: 'reports1', 'reloadRequired': 'reload:false', img: 'images/icons/geofenc_inact_icon.png' },
        { title: 'admin', link: 'home.admin', 'reloadRequired': 'reload:true', img: 'images/icons/admin_inact_icon.png' },
        { title: 'feedback', 'reloadRequired': 'reload:false', link: '/list/map', img: 'images/icons/feedback_inact_icon.png' }

    ];


	


    $scope.toggle = function() {
        $scope.toggleSide = !$scope.toggleSide;
        $rootScope.$broadcast('resizemap');

    };

    $scope.navToggle = function() {
		var myEl = angular.element( document.querySelector( '#wrapperInner' ) );
		myEl.toggleClass('wrappermargin'); 
        $scope.toggleSide1 = !$scope.toggleSide1;
		$scope.toggleSide = !$scope.toggleSide;
    };
    $scope.toggleSide1 = true;

}]);

equipmentPointApp.controller('EqDetailCtrl', ['$scope', '$rootScope', '$stateParams', 'mapDataTempStore', '$uibModal', '$http', '_', function($scope, $rootScope, $stateParams, mapDataTempStore, $uibModal, $http, _) {

    // princy div append
	
	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
	};
	
    var equipments = mapDataTempStore.getMapData().equipments;
    var found = _.select(equipments, function(node) {
        return node.EqIC === $stateParams.EqId;
    });

    $scope.equipmentItem = found[0];
	/* To view Generator or Pumps based on their EqType */
	$scope.generatorTab = found[0].EqType;
    $scope.pumpsTab = found[0].EqType;
    var latLng = new google.maps.LatLng($scope.equipmentItem.Lat, $scope.equipmentItem.Long);
    var alerts;
    if ($scope.equipmentItem.Alert > 0) {
        alerts = $scope.equipmentItem.Alert;
    } else { alerts = ''; }

    var marker = null;
    if ($scope.equipmentItem.Alert > 0) {
        marker = new MarkerWithLabel({
            position: latLng,

            labelContent: alerts,
            labelClass: 'labels1',
            labelStyle: {
                opacity: 0.75
            },
            icon: 'images/icons/markericons/eqicon_' + $scope.equipmentItem.EqType + '.png'
        });
    } else {
        marker = new google.maps.Marker({
            position: latLng,

            icon: 'images/icons/markericons/eqicon_' + $scope.equipmentItem.EqType + '.png'
        });
    }

    $scope.equipmentItem.position = angular.copy(marker.getPosition());
    $scope.equipmentItem.icon = angular.copy(marker.getIcon());


    $scope.dismiss = function() {
        $scope.$dismiss();
    };
		
    $scope.openDirections = function() {
        var modalInstanceDirections = $uibModal.open({
            templateUrl: 'views/directionpanel.html',
            backdrop: false,
            scope: $scope,
            controller: 'DirectionCtrl',
            animation: false,
            windowTopClass: 'directionWindow',
            appendTo: angular.element(document.querySelector('#wrapperInner')),
            resolve: {
                eqDetails: function() {
                    return $scope.equipmentItem;
                }
            }
        });
        modalInstanceDirections.result.then(function() {

        }, function() {});
    };

    $scope.openTrails = function(marker) {

        var modalInstanceDirections = $uibModal.open({
            templateUrl: 'views/trailpanel.html',
            backdrop: false,
            scope: $scope,
            controller: 'TrailCtrl',
            animation: false,
            windowTopClass: 'directionWindow trailWindow',
            appendTo: angular.element(document.querySelector('#wrapperInner')),

            resolve: {
                marker: function() {
                    return marker;
                }
            }
        });
        modalInstanceDirections.result.then(function() {

        }, function() {});
    };
	
    $scope.ok = function() {
        $scope.$close(true);
    };
    $scope.cancel = function() {
        $scope.$close(true);
    };
	 
	$scope.TimeUtilTblhrs = ['12AM','1AM','2AM','3AM','4AM','5AM','6AM','7AM','8AM','9AM','10AM','11AM','12PM','13PM','14PM','15PM','16PM','17PM','18PM','19PM','20PM','21PM','22PM','23PM'];
	
	$http.get('json/Timeline_utillization.json',{ cache: 'true' }).success(function(data){
		// $scope.TimeUtilTbldate = _.pluck(data.equipmentTimeline[0].equipmentTimeLineList,'Date');
			
		var temp_data = _.pluck(data.equipmentTimeline[0].equipmentTimeLineList, 'Begin_Datetime');
		
		$scope.TimeUtilTbldate = data.equipmentTimeline[0].equipmentTimeLineList;
		 var uniqueList = _.uniq(data.equipmentTimeline[0].equipmentTimeLineList, function(item, key,Date) {
			 return item.Date;			 
		 });
		 var tempJson = {};
		 for(var i=0; i<uniqueList.length;i++){
			var arr = [];
			for(var j = 0; j<$scope.TimeUtilTbldate.length;j++){
				if(uniqueList[i].Date == $scope.TimeUtilTbldate[j].Date){
					arr.push($scope.TimeUtilTbldate[j].Event_Code+'-'+(($scope.TimeUtilTbldate[j].Begin_Datetime).split(" ")[1]).split(':')[0]);
				}
			}
			tempJson[uniqueList[i].Date] = arr;
		 }
			$scope.hour = {};
			angular.forEach(tempJson, function(value, key){
				var tempary = {},temp_ar_hrs = [];
				angular.forEach(value, function(value1, key1){
					var hoursjson={};
					for(var i =1; i <=24; i++){
					if(temp_ar_hrs.indexOf(value1.split('-')[1]) == -1){
						if(value1.split('-')[1]  == i && value1.split('-')[0] == "HOF"){
							temp_ar_hrs.push(value1.split('-')[1]);
							hoursjson[i] = "HOF";
						} else 	if(value1.split('-')[1]  == i && value1.split('-')[0] == "HON"){
								temp_ar_hrs.push(value1.split('-')[1]);
									hoursjson[i] = "HON";
								} 
						else {
							hoursjson[i] = "";
						}	
					}
				 }
				 tempary[key1] = hoursjson;
				});
				$scope.hour[key] = tempary;
			});
			
			angular.forEach($scope.hour,function(value, key){
				angular.forEach(value,function(value2, key2){
					if(Object.keys(value2).length === 0 ){
						delete value[key2];
					  }
				});
			});
			// console.log(JSON.stringify($scope.hour));
	});
	$scope.temparrlength='';
	// $scope.temparrlength_1 = '';
	$scope.goWork = function(arg1,arg2,arg3,arg4){
		var result = false;
		if(arg3){
		$scope.temparrlength = (arg4+1);
		}
		var inp = arg2.match(/[a-zA-Z]+|[0-9]+/g)[0];
		if(Number(arg1) > Number(inp)){
		result = true;
		}
		return result;
	};
	
	$scope.goWork1 = function(arg1,arg2,arg3,arg4,arg5){
		var result = false;
		if(arg3){
		$scope.temparrlength_1 = (arg4+1);
		}
		var inp = arg2.match(/[a-zA-Z]+|[0-9]+/g)[0];
		if((Number(arg4) > Number($scope.temparrlength)) && Number(inp) > Number($scope.temparrlength)){
		if((Number(arg1) >= Number(inp))){
		result = true;
		}
		}
		return result;
	};
	
	$scope.goWork2 = function(arg1,arg2,arg3){
	var result = false;
	var inp = arg2.match(/[a-zA-Z]+|[0-9]+/g)[0];
	if(Number(inp) >= Number($scope.temparrlength)){
		result = true;
		}
	return result;
	}
	
	/* Assigned units Tap by prasanth */
	  $http.get('json/AssignedUnits.json', { cache: 'true' }).success(function(data) {
        $scope.assignunit = data.assignedEquipmentHistory;
    });
	
    /* Alert Tap by prasanth */	
    $http.get('json/AlertTab.json', { cache: 'true' }).success(function(data) {
        $scope.alertItem = data.alertDetails;
        $scope.pastAlertTotal = 0;
    });

    $http.get('json/Maintenance.json', { cache: 'true' }).success(function(data) {
        $scope.maintenance = data.MaintenanceHistory[0];
        console.log(JSON.stringify($scope.warrantyDate));
    });
	
	$scope.genPumpTabsCont = function(){
	/*Generator Tab*/
	$scope.generatorDashboard = [];
	$http.get('json/GeneratorDashboard.json',{ cache: 'true' }).success(function(data){
	$scope.generatorDashboard = data.GeneratorDashboard[0];
	// $scope.genrpm = data.generatorDashboard[0].engineRpm;
	// console.log(data.GeneratorDashboard[0].engineRpm);
	$scope.genrpm = 2250;
	// $scope.genfuellevel = data.generatorDashboard[0].fuelLevel;
	$scope.genfuellevel = 140;
	$scope.generatorstatus = 'off';
	});
	
	/*Pumps Tab*/
	$scope.pumpdashboard = [];
	$http.get('json/PumpDashboard.json',{ cache: 'true' }).success(function(data){
	$scope.pumpdashboard = data.PumpDashboard[0];
	$scope.oilpresure = data.PumpDashboard[0].oilPressure_I;
	$scope.dischargeoutletpressure = data.PumpDashboard[0].outletPressure_I;
	$scope.fuellevel = data.PumpDashboard[0].fuelLevel;
	$scope.rpm = data.PumpDashboard[0].batteryVoltage;
	$scope.batteryvoltage = data.PumpDashboard[0].rpm;
	// console.log( Math.floor(data.PumpDashboard[0].rpm / 100 ));
	});
	};
	$scope.genPumpTabsCont();
}]);


equipmentPointApp.controller('TrailCtrl', ['$q', 'NgMap', 'mapDataTempStore', '$interpolate', '$sce', '$templateRequest', '$scope', '$timeout', '$state', '$rootScope', '$uibModalInstance', 'marker', '$http', function($q, NgMap, mapDataTempStore, $interpolate, $sce, $templateRequest, $scope, $timeout, $state, $rootScope, $uibModalInstance, marker, $http) {

    $scope.init = function() {

       

        $scope.render = true;
        $scope.$on('mapInitialized', function(evt, map) {
            addYourLocationButton(map);

            //MAP CONTROL

            function attachMarkerEvent(marker) {
                google.maps.event.addListener(marker, 'click', function() {
                    $scope.vm = marker;
                    var Locater = new google.maps.Geocoder();
                    Locater.geocode({
                        latLng: marker.getPosition()
                    }, function(responses) {
                        if (responses && responses.length > 0) {
                            // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
                            var address = responses[0].formatted_address;
                            $scope.address = address;
                            map.showInfoWindow('marker_window', marker);

                        } else {
                            var msg = 'Cannot determine address at this location.';
                            $scope.address = msg;
                            map.showInfoWindow('marker_window', marker);
                        }
                    });
                });
            }

            function formatDate(date) {
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var ampm = hours >= 12 ? 'pm' : 'am';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                minutes = minutes < 10 ? '0' + minutes : minutes;
                var strTime = hours + ':' + minutes + ' ' + ampm;
                return strTime;
                //return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear() + "  " + strTime;
            }

            // var data = { "equipmentTrail": [{ "isIgnitionOn": 2, "latitude": "32.820022", "longitude": "-97.411483", "reportDate": "2016-02-03T11:41:00.000Z" }, { "isIgnitionOn": 0, "latitude": "32.820028", "longitude": "-97.411467", "reportDate": "2016-02-03T15:03:00.000Z" }, { "isIgnitionOn": 1, "latitude": "32.820022", "longitude": "-97.411483", "reportDate": "2016-02-03T15:03:00.000Z" }, { "isIgnitionOn": 2, "latitude": "32.820028", "longitude": "-97.411467", "reportDate": "2016-02-03T16:41:00.000Z" }, { "isIgnitionOn": 0, "latitude": "32.820028", "longitude": "-97.411467", "reportDate": "2016-02-03T17:41:00.000Z" }, { "isIgnitionOn": 1, "latitude": "32.820028", "longitude": "-97.411467", "reportDate": "2016-02-03T18:41:00.000Z" }] }
            var lastMarker = {};
            var markerPoints = [];

            Date.prototype.addTime = function(h, m, s) {
                this.setHours(this.getHours() + h);
                this.setMinutes(this.getMinutes() + m);
                this.setSeconds(this.getSeconds() + s);
                return this;
            };

            function fetch(dt, temp) {
                var shapes, circle;
                var clearShapes = function() {
                    for (var i = 0; i < shapes.length; ++i) {
                        shapes[i].setMap(null);
                    }
                    shapes = [];
                };

                var url = 'scripts/map/Trail2.json?dt=';
                if (temp === 1) {
                    url = 'scripts/map/Trail3.json?dt=';
                }
                angular.forEach(markerPoints, function(marker) {
                    marker.setMap(null);
                });
                if (typeof(shapes) !== 'undefined') {
                    clearShapes();
                }
                if (typeof(circle) !== 'undefined') {

                    circle.setMap(null);
                }

                $http.get(url + dt.toISOString())
                    .then(function(response) {
                        var bounds = new google.maps.LatLngBounds();
                        var fencedata = [{ 'type': 'CIRCLE', 'id': null, 'radius': 43451.1, 'geometry': [32.820028, -97.41146700000002] }];
                        shapes = IO.OUT(fencedata, map);
                        $scope.sliderValue = fencedata[0].radius / 1609.3;
                        map.setZoom(999);
                        map.hideInfoWindow('marker_window');
                        bounds.union(shapes[0].getBounds());

                        var markers = response.data.equipmentTrail;
                        var engineOnHrs = new Date(),
                            engineOffHrs = new Date();
                        engineOnHrs.setHours(0, 0, 0, 0);
                        engineOffHrs.setHours(0, 0, 0, 0);
                        var engineOnTime, engineOffTime;
                        var engineOn = false,
                            engineOff = false;
                        var engineOnDiff, engineOffDiff;
                        var hh, mm, ss, msec;
                        var onMarkers = [],
                            offMarkers = [];
                        for (var i = 0; i < markers.length; i++) {
                            var engineStatus;
                            var markerTime = new Date(markers[i].reportDate);
                            var latLng = new google.maps.LatLng(markers[i].latitude, markers[i].longitude);
                            var color;
                            var marker;

                            switch (markers[i].isIgnitionOn) {
                                case 0:
                                    color = 'red';
                                    engineOffTime = markerTime;
                                    if (engineOn === true) {
                                        engineOnDiff = markerTime - engineOnTime;
                                        msec = engineOnDiff;
                                        hh = Math.floor(msec / 1000 / 60 / 60);
                                        msec -= hh * 1000 * 60 * 60;
                                        mm = Math.floor(msec / 1000 / 60);
                                        msec -= mm * 1000 * 60;
                                        ss = Math.floor(msec / 1000);
                                        msec -= ss * 1000;
                                        engineStatus = 'Engine Off - ' + hh + ':' + mm + ':' + ss;
                                        marker.setCustomData('engineStatus', engineStatus);

                                        marker.setCustomData('timeStart', formatDate(engineOnTime));
                                        marker.setCustomData('timeEnd', formatDate(markerTime));

                                        engineOnHrs.addTime(hh, mm, ss);
                                        engineOn = false;
                                    }
                                    engineOff = true;
                                    break;
                                case 1:
                                    color = 'green';
                                    engineOn = true;
                                    engineOnTime = markerTime;
                                    if (engineOff === true) {
                                        engineOffDiff = markerTime - engineOffTime;
                                        msec = engineOffDiff;
                                        hh = Math.floor(msec / 1000 / 60 / 60);
                                        msec -= hh * 1000 * 60 * 60;
                                        mm = Math.floor(msec / 1000 / 60);
                                        msec -= mm * 1000 * 60;
                                        ss = Math.floor(msec / 1000);
                                        msec -= ss * 1000;
                                        engineStatus = 'Engine On - ' + hh + ':' + mm + ':' + ss;

                                        marker.setCustomData('engineStatus', engineStatus);

                                        marker.setCustomData('timeStart', formatDate(engineOffTime));
                                        marker.setCustomData('timeEnd', formatDate(markerTime));

                                        engineOffHrs.addTime(hh, mm, ss);
                                        engineOff = false;
                                    }
                                    engineOn = true;

                                    break;
                                case 2:
                                    color = 'yellow';
                                    break;
                            }
                            marker = new MarkerWithLabelTrails({
                                position: latLng,
                                map: map,
                                labelContent: (i + 1).toString(),
                                labelClass: 'labels2',
                                //  labelAnchor: new google.maps.Point(10, 33),
                                labelInBackground: false,

                                zIndex: google.maps.Marker.MAX_ZINDEX + i
                            });

                            marker.setIcon('images/icons/trialicons/marker_' + color + '.png');



                            var curDate = new Date(markers[i].reportDate); // 5:00 PM


                            // var StartDate;
                            // if (i === 0) {
                            //     var StDate = "2016-05-02T00:00:00.000Z";
                            //     StartDate = new Date(StDate);
                            // } else {
                            //     StartDate = new Date(markers[i - 1].reportDate);
                            // }

                            // // the following is to handle cases where the times are on the opposite side of
                            // // midnight e.g. when you want to get the difference between 9:00 PM and 5:00 AM

                            // if (curDate < StartDate) {
                            //     curDate.setDate(curDate.getDate() + 1);
                            // }

                            // var diff = curDate - StartDate;
                            // msec = diff;
                            // hh = Math.floor(msec / 1000 / 60 / 60);
                            // msec -= hh * 1000 * 60 * 60;
                            // mm = Math.floor(msec / 1000 / 60);
                            // msec -= mm * 1000 * 60;
                            // ss = Math.floor(msec / 1000);
                            // msec -= ss * 1000;
                            // var diffTime = hh + ':' + mm + ':' + mm;
                            var formattedDate = formatDate(curDate);
                            //marker.setCustomData('timeDiff', diffTime);
                            marker.setCustomData('currentTime', formattedDate);
                            markerPoints.push(marker);
                            if (i === markers.length - 1) {
                                lastMarker = marker;
                            }

                            bounds.extend(latLng);

                            google.maps.event.addListener(map, 'zoom_changed', function() {});
                            attachMarkerEvent(marker);
                            switch (markers[i].isIgnitionOn) {
                                case 0:
                                    offMarkers.push(marker);
                                    break;
                                case 1:
                                    onMarkers.push(marker);
                                    break;

                            }


                        }

                        $scope.offTime = engineOffHrs.getHours() + ':' + engineOffHrs.getMinutes() + ':' + engineOffHrs.getSeconds();
                        $scope.onTime = engineOnHrs.getHours() + ':' + engineOnHrs.getMinutes() + ':' + engineOnHrs.getSeconds();

                        $scope.path = markers.map(function(marker) {
                            return [marker.latitude, marker.longitude];
                        });


                        map.fitBounds(bounds);
                        var circle;
                        $scope.cancel = function() {
                            angular.forEach(markerPoints, function(marker) {
                                marker.setMap(null);
                            });
                            clearShapes();
                            if (typeof(circle) !== 'undefined') {

                                circle.setMap(null);
                            }
                            $uibModalInstance.dismiss('cancel');

                        };

                        $scope.redrawFence = function() {

                            clearShapes();

                            if (typeof(circle) !== 'undefined') {

                                circle.setMap(null);
                            }

                            circle = new google.maps.Circle({
                                map: map,
                                radius: $scope.sliderValue * 1609.3, // 1 miles in metres
                                fillColor: '#ee9e8d',
                                strokeColor: '#ee6144',
                                strokeOpacity: 0.8,
                                strokeWeight: 2
                            });
                            circle.bindTo('center', lastMarker, 'position');
                            bounds.extend(latLng);

                            map.fitBounds(circle.getBounds());

                            $scope.showAssignButton = true;
                            $scope.showTrails = false;
                        };
                        $scope.showTrails = true;

                        var oldSlideValue;
                        $scope.slideOldValue = function() {
                            oldSlideValue = $scope.sliderValue;

                        };

                        if ($scope.sliderValue > 0) {
                            $scope.showDeleteButton = true;
                        }
                        $scope.deleteTrails = function() {
                            $scope.showConfirmDeleteButton = true;

                        };

                        $scope.cancelTrail = function() {

                            $scope.sliderValue = oldSlideValue;
                            $scope.redrawFence(undefined, $scope.sliderValue);
                            $scope.showTrails = true;
                            $scope.showAssignButton = false;
                        };

                        $scope.cancelDelete = function() {
                            $scope.showConfirmDeleteButton = false;

                        };

                        $scope.assignGeoFence = function() {
                            var tmp = { type: IO.t_('circle'), id: null };

                            tmp.radius = circle.getRadius();
                            tmp.geometry = IO.p_(circle.getCenter());

                            $scope.geoFence = '';

                            var data = {
                                json: JSON.stringify({
                                    EqIC: $scope.equipmentItem.EqIC,
                                    geoFence: tmp
                                })
                            };

                            //json:"{"EqIC":"0061802530","geoFence":{"type":"CIRCLE","id":null,"radius":67590.59999999999,"geometry":[32.820038,-97.411498]}}"
                            $http.post('/savegeofence/', data).success(function() {
                                $scope.alerts = [
                                    { type: 'info', msg: 'GeoFence saved' },

                                ];
                            });

                            $scope.showAssignButton = false;
                            $scope.showTrails = true;
                        };

                        $scope.confirmDeleteTrail = function() {
                            var data = {
                                json: JSON.stringify({
                                    EqIC: $scope.equipmentItem.EqIC

                                })
                            };

                            $http.post('/deletegeofence/', data).success(function() {
                                $scope.alerts = [
                                    { type: 'info', msg: 'GeoFence Deleted' },

                                ];
                            });

                            $scope.showConfirmDeleteButton = false;
                            $scope.showTrails = true;
                        };

                        $scope.engineOnToggle = false;
                        $scope.engineOn = function() {
                            $scope.engineOnToggle = !$scope.engineOnToggle;
                            if ($scope.engineOnToggle === true) {

                                angular.forEach(offMarkers, function(marker) {
                                    marker.setMap(null);
                                });
                            } else {
                                angular.forEach(offMarkers, function(marker) {
                                    marker.setMap(map);
                                });

                            }

                        };

                        $scope.engineOffToggle = false;
                        $scope.engineOff = function() {
                            $scope.engineOffToggle = !$scope.engineOffToggle;
                            if ($scope.engineOffToggle === true) {

                                angular.forEach(onMarkers, function(marker) {
                                    marker.setMap(null);
                                });
                            } else {
                                angular.forEach(onMarkers, function(marker) {
                                    marker.setMap(map);
                                });

                            }

                        };
                        google.maps.event.addListener(map, 'click', function() {

                            map.hideInfoWindow('marker_window');
                        });
                        google.maps.event.addListener(map, 'zoom_changed', function() {

                            map.hideInfoWindow('marker_window');

                        });

                        $scope.closeAlert = function(index) {
                            $scope.alerts.splice(index, 1);
                        };
                    });
            }

            //date
            $scope.today = function() {
                $scope.dt = new Date();
            };
            $scope.today();

            $scope.clear = function() {
                $scope.dt = null;
            };

            // Disable weekend selection
            function disabled(data) {
                var date = data.date,
                    mode = data.mode;
                return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
            }

            function getDayClass(data) {
                var date = data.date,
                    mode = data.mode;
                if (mode === 'day') {
                    var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                    for (var i = 0; i < $scope.events.length; i++) {
                        var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                        if (dayToCheck === currentDay) {
                            return $scope.events[i].status;
                        }
                    }
                }

                return '';
            }

            $scope.inlineOptions = {
                customClass: getDayClass,
                minDate: new Date(),
                showWeeks: true
            };

            $scope.dateOptions = {
                dateDisabled: disabled,
                formatYear: 'yy',
                maxDate: new Date(2020, 5, 22),
                minDate: new Date(),
                startingDay: 1
            };

            $scope.toggleMin = function() {
                $scope.inlineOptions.minDate = $scope.inlineOptions.minDate ? null : new Date();
                $scope.dateOptions.minDate = $scope.inlineOptions.minDate;
            };

            $scope.toggleMin();

            $scope.open1 = function() {
                $scope.popup1.opened = true;
            };

            $scope.open2 = function() {
                $scope.popup2.opened = true;
            };

            $scope.setDate = function(year, month, day) {
                $scope.dt = new Date(year, month, day);
            };

            $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
            $scope.format = $scope.formats[0];
            $scope.altInputFormats = ['M!/d!/yyyy'];

            $scope.popup1 = {
                opened: false
            };

            $scope.popup2 = {
                opened: false
            };

            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var afterTomorrow = new Date();
            afterTomorrow.setDate(tomorrow.getDate() + 1);
            $scope.events = [{
                date: tomorrow,
                status: 'full'
            }, {
                date: afterTomorrow,
                status: 'partially'
            }];


            $scope.selectDate = function() {



                fetch($scope.dt, 1);
            };

            function getPrevNextDate(date, increment) {

                var newDate = new Date();
                newDate.setDate(date.getDate() + increment);
                return newDate;
            }

            $scope.prevDay = function() {

                $scope.dt = getPrevNextDate($scope.dt, -1);

                fetch($scope.dt, 0);
            };

            $scope.nextDay = function() {

                $scope.dt = getPrevNextDate($scope.dt, 1);
                fetch($scope.dt, 1);
            };
            //date

            //MAP CONTROL
            function CenterControlLeft(controlDiv) {
                // Set CSS for the control border.
                var controlUILeft = document.createElement('div');
                // controlUI.style.backgroundColor = '#fff';
                controlUILeft.style.border = '2px solid #fff';
                controlUILeft.style.borderRadius = '3px';
                controlUILeft.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
                controlUILeft.style.cursor = 'pointer';
                controlUILeft.style.marginBottom = '22px';
                controlUILeft.style.textAlign = 'center';

                var imgLeft = document.createElement('img');
                imgLeft.src = 'images/control_lefticon.jpg';
                controlUILeft.appendChild(imgLeft);
                controlDiv.appendChild(controlUILeft);
                // Setup the click event listeners: simply set the map to Chicago.
                controlUILeft.addEventListener('click', function() {

                    this.dt = getPrevNextDate($scope.dt, -1);
                    fetch(this.dt, 0);
                });

            }

            function CenterControlRight(controlDiv) {

                // Set CSS for the control border.
                var controlUI = document.createElement('div');
                // controlUI.style.backgroundColor = '#fff';
                controlUI.style.border = '2px solid #fff';
                controlUI.style.borderRadius = '3px';
                controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
                controlUI.style.cursor = 'pointer';
                controlUI.style.marginBottom = '22px';
                controlUI.style.textAlign = 'center';

                var imgRight = document.createElement('img');
                imgRight.src = 'images/control_righticon.jpg';
                controlUI.appendChild(imgRight);

                controlDiv.appendChild(controlUI);

                // Setup the click event listeners: simply set the map to Chicago.
                controlUI.addEventListener('click', function() {

                    this.dt = getPrevNextDate($scope.dt, 1);
                    fetch(this.dt, 1);
                });

            }

            var centerControlDivLeft = document.createElement('div');
            new CenterControlLeft(centerControlDivLeft, map);

            centerControlDivLeft.index = 1;
            map.controls[google.maps.ControlPosition.LEFT_CENTER].push(centerControlDivLeft);

            var centerControlDivRight = document.createElement('div');
            new CenterControlRight(centerControlDivRight, map);

            centerControlDivRight.index = 1;
            map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(centerControlDivRight);

            var currentDate = new Date();
            fetch(currentDate);
        });
    };
}]);
