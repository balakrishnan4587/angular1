equipmentPointApp.controller('reportController',['$scope','$http','reportServices',function($scope,$http,reportServices){
	$scope.loadreport = function(){
	 var url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/'+$scope.reportType+'?Division='+HG+'&UserType='+H+'&UserNbr='+demoh10+'&FromDate='+frm+'&ToDate='+to;
	
		reportServices.getServiceData('json/WarrantyListJson.json').success(function(data){
		$scope.headercolumn = [];
		$scope.responseData;
		var counter = 0;
		// angular.forEach(data,function(value,key){
		// var temp = ("data."+$scope.reportType);
		$scope.responseData = eval("data."+$scope.reportType);
		$scope.displayedCollection = [].concat($scope.responseData);
		// console.log( );
		_.each(eval($scope.responseData),function(value1,index){
			if(counter == 0 ){
				$scope.headercolumn = _.keys(value1);
			 }
			},eval($scope.responseData));
		//});
		 // console.log(JSON.stringify($scope.headercolumn));
		})
		.error(function(data){
			console.log(data);
		});
	}
	
	/* #################### navaneeth to test*/
	
	$scope.testData = {  "equipmentTimeline":[     {        "endTime":"1900-01-01 23:59:59.000",        "equipmentTimeLineList":[           {              "Begin_Datetime":"2016-03-02 15:00:00.000",              "Date":"03\/02\/16",              "End_Datetime":"2016-03-02 15:16:49.000",              "Event_Code":"HOF",              "Extended_Data":"16 mins"           },           {              "Begin_Datetime":"2016-03-02 15:16:49.000",              "Date":"03\/02\/16",              "End_Datetime":"2016-03-02 15:19:55.000",              "Event_Code":"HOF",              "Extended_Data":"3 mins"           },           {              "Begin_Datetime":"2016-03-02 15:19:55.000",              "Date":"03\/02\/16",              "End_Datetime":"2016-03-02 15:21:17.000",              "Event_Code":"HOF",              "Extended_Data":"1 min"           },{              "Begin_Datetime":"2016-03-02 17:19:55.000",              "Date":"03\/02\/16",              "End_Datetime":"2016-03-02 17:21:17.000",              "Event_Code":"HON",              "Extended_Data":"1 min"           },{              "Begin_Datetime":"2016-03-02 22:19:55.000",              "Date":"03\/02\/16",              "End_Datetime":"2016-03-02 22:21:17.000",              "Event_Code":"HON",              "Extended_Data":"1 min"           },           {              "Begin_Datetime":"2016-04-02 15:21:17.000",              "Date":"04\/02\/16",              "End_Datetime":"2016-04-02 15:48:59.000",              "Event_Code":"HOF",              "Extended_Data":"27 mins"           },           {              "Begin_Datetime":"2016-04-02 15:48:59.000",              "Date":"04\/02\/16",              "End_Datetime":"2016-04-02 15:51:22.000",              "Event_Code":"HON",              "Extended_Data":"2 mins"           },           {              "Begin_Datetime":"2016-04-02 15:51:22.000",              "Date":"04\/02\/16",              "End_Datetime":"2016-04-02 15:51:45.000",              "Event_Code":"HOF",              "Extended_Data":"0 min"           },           {              "Begin_Datetime":"2016-05-02 16:03:45.000",              "Date":"05\/02\/16",              "End_Datetime":"2016-05-02 16:51:17.000",              "Event_Code":"HON",              "Extended_Data":"11 mins"           },           {              "Begin_Datetime":"2016-05-02 16:03:17.000",              "Date":"05\/02\/16",              "End_Datetime":"2016-05-02 23:59:59.000",              "Event_Code":"HOF",              "Extended_Data":"7 hours 56 mins"           },           {              "Begin_Datetime":"2016-05-02 23:59:59.000",              "Date":"05\/02\/16",              "End_Datetime":"2016-05-02 00:00:00.000",              "Event_Code":"HOF",              "Extended_Data":"-59 min"           }        ],        "startTime":"1900-01-01 15:00:00.000"     }  ]};

	//var stooges = [$scope.testData.equipmentTimeline.equipmentTimeLineList.Begin_Datetime];
	
	//	console.log(_.pluck($scope.testData, 'Begin_Datetime'));
	var log11 = [];
	var log22 = [];
	var constr = '';
	console.log($scope.testData.equipmentTimeline[0].equipmentTimeLineList.length);
	var data11 = $scope.testData.equipmentTimeline[0].equipmentTimeLineList;
	angular.forEach(data11, function(value11, key11) {
		this.push(value11);		
	}, log11);
	
	angular.forEach(log11, function(value22, key22) {
	var constr = [];
	var constr = '{date:'+value22.Date+'},{Event_Code:'+ value22.Event_Code+'},{time:'+ value22.Begin_Datetime+'}';		
		this.push(constr);		
	}, log22);
	
	console.log(log11);
	console.log(log22);
	
		console.log(_.uniq(log22));
	
}]);