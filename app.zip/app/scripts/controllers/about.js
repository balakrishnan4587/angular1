'use strict';

/**
 * @ngdoc function
 * @name myt1App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the myt1App
 */
angular.module('EquipmentPointApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
