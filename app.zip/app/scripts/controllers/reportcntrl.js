	equipmentPointApp.controller('reportController',['$scope','$http','uiGridConstants','reportServices','toggleFromToFactory','usernameService',function($scope,$http,uiGridConstants,reportServices,toggleFromToFactory,usernameService){
	
	var url1;
	$scope.isStDateShow = true;
	$scope.division = 'HG';
	$scope.UserType = 'H';
	$scope.EquipIC = '123456';
	$scope.status = 'A';
	$scope.span = 'W';
	$scope.ToggleFromTo = function(){
		// var x = toggleFromToFactory.getCaseNo($scope.reportType);
		switch(toggleFromToFactory.getCaseNo($scope.reportType)){
			case 1 :
				$scope.isStDateShow = true;
				$scope.isToDateShow = true;
				url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/'+$scope.reportType+'?Division='+$scope.division+'&UserType='+$scope.UserType+'&UserNbr=demoh10&FromDate='+$scope.reportStDate+'&ToDate='+$scope.reportToDate+'&Status='+$scope.status;
					break;
			case 2 :
				$scope.isStDateShow = true;
				$scope.isToDateShow = false;
				url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/'+$scope.reportType+'&UserNbr=demoh10&FromDate='+$scope.reportStDate+'&Span=W';
					break;
			case 3 :
				$scope.isStDateShow = false;
				$scope.isToDateShow = false;
				url1 ='http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/'+$scope.reportType+'?Division='+$scope.division+'&UserType=H&UserNbr=demoh10'
					break;
			case 4 :
				$scope.isStDateShow = false;
				$scope.isToDateShow = true;
				url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/'+$scope.reportType+'?Division='+$scope.division+'&UserType='+$scope.UserType+'&UserNbr=demoh10&ToDate='+$scope.reportToDate+'&span=W';
					break;
			case 5 :
				$scope.isStDateShow = true;
				$scope.isToDateShow = true;
				url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/'+$scope.reportType+'?Division='+$scope.division+'&UserType='+$scope.UserType+'&UserNbr=demoh10&FromDate='+$scope.reportStDate+'&ToDate='+$scope.reportToDate;
					break;
			case 6 :
				$scope.isStDateShow = false;
				$scope.isToDateShow = false;
					url1 = 'http://devtelewebsvc.hercrentals.com/Report.svc/Equipments/800076208/'+$scope.reportType+'?Division='+$scope.division+'&FromDate='+$scope.reportStDate+'&ToDate='+$scope.reportToDate;
					break;
		}
	}
	
	$scope.gridOptions3 = {
													enableSorting: true,
													selectionRowHeaderWidth: 50,
													enableHorizontalScrollbar : uiGridConstants.scrollbars.ALWAYS,
													rowHeight: 50,
													rowWidth : 250,
													onRegisterApi: function( gridApi ) {
													  $scope.grid1Api = gridApi;
													}
						};
	$scope.loadreport = function(){
		console.log($scope.reportToDate);
		reportServices.getServiceData(url1).success(function(data){
		$scope.gridOptions3.data = data[$scope.reportType];
			$scope.gridOptions3.columnDefs = [];
			var counter = 0;
			_.each($scope.gridOptions3.data,function(value1,index){
				_.each(value1,function(value2,index2){
					if(counter == 0 ){
					$scope.gridOptions3.columnDefs.push({
					 name: index2,
					 width: 150
					});
				  }
				});
				counter++;
			});
		}).error(function(data){
			console.log(data);
		});
	}
}]);

equipmentPointApp.factory('toggleFromToFactory',function(){
	var factory = {};
	return {
	getCaseNo : function(arg){
		var array1 = ['ScheduledForPickup'];
		var array2 = ['DTCReport'];
		var array3 = ['EquipmentNotReporting','PickupStatusUsage','MeterOverage'];
		var array4 = ['PickupStatusUsageSummary','MeterOverageSummary','GetUtilizationReportResult'];
		var array5 = ['FuelLevelReport','EquipmentMaintenanceReport','EquipmentInspectionReport','EquipmentWarrantyReport'];
		var array6 = ['AllActivity'];
		var result;
		if(array1.indexOf(arg) > -1)
		result = 1;
		else if(array2.indexOf(arg) > -1)
		result = 2;
		else if(array3.indexOf(arg) > -1)
		result = 3;
		else if(array4.indexOf(arg) > -1)
		result = 4;
		else if(array5.indexOf(arg) > -1)
		result = 5;
		else if(array6.indexOf(arg) > -1)
		result = 6;
		return result;
		}
	}
});

equipmentPointApp.directive('pageHeight',function($window){
	return  {
	link : function(scope, element, attr ) { 
			//var windowobj = angular.element($window);
			console.log($window.innerWidth+'Height---->'+$window.innerHeight);
			element.css('height',($window.innerHeight-180)+'px'); // set height
			element.css('width',($window.innerWidth)+'px'); // set width
			element.css('overflow','scroll');
		}
	}
});

equipmentPointApp.directive('datepicker',function(){
		return {
			restrict : 'A',
			require: 'ngModel',
			link: function(scope, el, attr, ngModel) {
				el.datetimepicker({
					format : 'yyyy-mm-dd'
				});
			}
		}
});