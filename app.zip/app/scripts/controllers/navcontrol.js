'use strict';

angular.module('myt1App')
    .controller('NavCtrl', function($scope, $element,$http,$rootScope,$location) {

//NavCtrl not in use now. see MainCtrl in mapcntrl.js

        $scope.navMenu = [
        { title: 'Dashboard', link: 'dashboard', 'reloadRequired': 'reload:false', img: 'images/icons/db_inact_icon.png'},
		{ title: 'equipment', link: 'home.main', 'reloadRequired': 'reload:true',
                img: 'images/icons/equipment_inact_icon.png' }, 
		{ title: 'Reports', link: 'report', 'reloadRequired': 'reload:false', img: 'images/icons/report_inact_icon.png' }, { title: 'geo fence', link: 'geo', 'reloadRequired': 'reload:false', img: 'images/icons/geofenc_inact_icon.png' }, { title: 'admin', link: 'home.admin', 'reloadRequired': 'reload:true', img: 'images/icons/admin_inact_icon.png' },  { title: 'feedback', 'reloadRequired': 'reload:false', link: '/list/map', img: 'images/icons/feedback_inact_icon.png' }

        ];
		
		var totalAlerts = 0;
		$http.get('json/TopAlert.json', { cache: 'true' }).success(function(data) {
		var sampData = [];
        for (var item = 0; item < data.activeAlertDetails.length; item++) {
			if(Number(data.activeAlertDetails[item].totalCount) != 0){
			sampData.push(data.activeAlertDetails[item]);
			}
            totalAlerts += Number(data.activeAlertDetails[item].totalCount);
        }
		$scope.sampDataJ = sampData;
		$scope.activeAlertsTxt = sampData.length;
		console.log(totalAlerts);
        $rootScope.totalAlerts = totalAlerts;
		});
		
        $scope.status = { 
            isopen: false
        };

        $scope.toggled = function() {
		
        };
		
		$scope.loggedOut = function() {
		alert("logout");
		console.log('loggedOut');
		$rootScope.loggedUser = undefined;
		$location.path("/login");
		}
		
        $scope.toggleDropdown = function($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.status.isopen = !$scope.status.isopen;
        };

        $scope.appendToEl = angular.element(document.querySelector('#dropdown-long-content'));
        $scope.toggle = function() {
            $element.find('#wrapper').toggleClass('toggled');
        };
		$scope.menuhide = function() {
            var myEl = angular.element( document.querySelector( 'body' ) )
			myEl.removeClass('lateral-slide-menu-in-transition'); 
			myEl.removeClass('lateral-slide-menu-is-open'); 
        };
    });
