'use strict';

/**
 * @ngdoc overview
 * @name myt1App
 * @description
 * # myt1App
 *
 * Main module of the application.
 */

var underscore = angular.module('underscore', []);
underscore.factory('_', ['$window', function($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);
var equipmentPointApp = angular
    .module('EquipmentPointApp', [
        'ui.router',
        'ngCookies',
        'ngResource',
        'ngSanitize',
        'ui.bootstrap',
        'ngTouch', 'ui.bootstrap', 'ui.bootstrap-slider', 'smart-table', 'angular-loading-bar', 'nvd3ChartDirectives', 'underscore', 'ngMap', 'ap.lateralSlideMenu','ui.knob','n3-line-chart','ngScrollbar','angular-dialgauge','angular.filter','ui.grid','angularjs-datetime-picker'
    ])
	.controller('myctrl', function ($scope) {
		$scope.$on('scrollbar.show', function(){
		  console.log('Scrollbar show');
		});
		$scope.$on('scrollbar.hide', function(){
		  console.log('Scrollbar hide');
		 });
	  })
    .directive('pvScrolled', function() {
        return function(scope, elm, attr) {
            var raw = elm[0];
            elm.bind('scroll', function() {
                if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) { scope.$apply(attr.pvScrolled); } }); }; })
    
    .config(function($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/login');
        $stateProvider
            .state('login', {
                url: '/login',
                templateUrl: 'views/login.html',
                controller: 'LoginCtrl',
                hideNavbar: true
            }).state('reports', {
                url: '/reports',
                templateUrl: 'views/reportMain.html',
                controller: 'reportController'
            })
            .state('dashboard', {
                url: '/dashboard',
                templateUrl: 'views/dashboard.html'
            })
            .state('home', {
                abstract: true,
                templateUrl: 'views/main.html',
                controller: 'MainCtrl'
            }).state('home.main', {
                url: '/map',
                views: {
                    'left@home': {
                        templateUrl: 'views/eqlist.html',
                        controller: 'equipmentsListCtrl'
                    },
                    'right@home': {
                        templateUrl: 'views/map.html',
                        controller: 'MapCtrl'
                    }
                }

            })
            // .state('home.main.detail', {
              // params: {
                 // EqId: null,
             // },

            // views: {

              // 'right@home': {
                  // templateUrl: 'views/detail.html',
                   // controller: 'EqDetailCtrl'
              // }
         // }

        // })
        .state('home.main.left', {
                params: {
                    EqIds: null,
                },
                views: {
                    //'': { templateUrl: 'views/home.html' },
                    'left@home': {
                        templateUrl: 'views/eqlist.html',
                        controller: 'equipmentsListCtrl'

                    }
                }
            }).state('home.admin', {
                url: '/admin',
                views: {
                    'left@home': {
                        templateUrl: 'views/admineqlist.html',
                        controller: 'adminequipmentsListCtrl'
                    },
                    /* 'right@home': {
                        templateUrl: 'views/admindetail.html',
                        controller: 'EqAdminDetailCtrl'
                    }  */
                }

            })
            .state('home.admin.eqlistdetail', {
                params: {
                    EqAdId: null,
                    EqAdStat: null,
                },
                views: {
                    'right@home': {
                        templateUrl: 'views/admindetail.html',
                        controller: 'EqAdminDetailCtrl'
                    }
                }

            })
            .state('home.admin.eqlistassi', {
                params: {
                    EqAdId: null,
                    EqAdStat: null,
                },
                views: {
                    'right@home': {
                        templateUrl: 'views/adminassi.html',
                        controller: 'EqAdminDetailCtrl'
                    }
                }

            })
            .state('home.main.detail', {
                params: {
                    EqId: null,
                },
                onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
				
                   $uibModal.open({
                        templateUrl: 'views/detail.html',
                        windowClass: 'detail_window',
                        backdrop: false,
                        animation: false,
                        appendTo: angular.element(document.querySelector('#containerfluid')),
                        controller: 'EqDetailCtrl'
                            //                        , resolve: {
                            //                             item: function() {
                            //                                 var equipments = mapDataTempStore.getMapData().equipments;
                            //                                 var found = _.select(equipments, function(node) {
                            //                                     return node.EqIC === $stateParams.EqId
                            //                                 });
                            //                                 return found[0];


                        //                             }
                        //                         },
                        //                         controller: ['$scope', 'item', function($scope, item) {
                        //                             $scope.dismiss = function() {
                        //                                 $scope.$dismiss();
                        //                             };
                        //                             $scope.equipmentItem = item


                        //       $scope.openDirections = function(marker) {
                        // console.log("a1")
                        // console.log(marker)

                        //                 var modalInstanceDirections = $uibModal.open({
                        //                     templateUrl: 'views/directionpanel.html',
                        //                     backdrop: false,
                        //                     scope: $scope,
                        //                     controller: 'DirectionCtrl',
                        //                     animation: false,
                        //  windowTopClass:'directionWindow',

                        //                     resolve: {
                        //                         marker: function() {
                        //                             return marker;
                        //                         } 
                        //                     }
                        //                 });
                        //                 modalInstanceDirections.result.then(function(selectedItems) {

                        //                 }, function() {});
                        //             };


                        //                             $scope.ok = function() {
                        //                                 $scope.$close(true);
                        //                             };
                        //                             $scope.cancel = function() {
                        //                                 $scope.$close(true);
                        //                             };


                        //                         }]
                    }).result.finally(function() {
                        $state.go('^');
                    });
                }]
            }).state("equipNotRep",{
				url: '/equipNotRep',
                templateUrl: 'views/equipNotRep.html',
                controller: 'equipNotRepCtrl'
			})
			.state("equipOnAlert",{
				url: '/equipOnAlert',
                templateUrl: 'views/equipOnAlert.html',
                controller: 'equipOnAlertCtrl'
			});
    });
equipmentPointApp.service('number', function() {
    return {
        isPositive: function(operationPrice) {
            return String(operationPrice).indexOf('-') === -1;
        }
    };
});

equipmentPointApp.service('reportServices', function($http) {
    return {
        getServiceData: function(url) {
            return $http.get(url);
        }
    };
});

// equipmentPointApp.run(function($rootScope, $location){console.log('Test');
// $rootScope.$on( "$stateChangeStart", function(event, toState, toParams, fromState, fromParams) {
// console.log('Logged In User..'+$rootScope.loggedUser);
// // if ( $rootScope.loggedUser === undefined ) {
// // $location.path("/login");
// // }
// });
// });

equipmentPointApp.filter('splitfortime',function(){
		return function(input,$scope){
		var firstSplit = input.split(" ")[1];
		console.log('split for time   '+firstSplit.split(":")[0]+':'+firstSplit.split(":")[1]);
		return (firstSplit.split(":")[0]);
	}
});

equipmentPointApp.filter('removemeritium',function(){
		return function(input){
		//var meridiem = input.match(/[a-zA-Z]+|[0-9]+/g)[0]+':'+input.match(/[a-zA-Z]+|[0-9]+/g)[1];
		var meridiem = input.match(/[a-zA-Z]+|[0-9]+/g)[0];
		// console.log(meridiem);
		return (meridiem);
		}
});

equipmentPointApp.filter('removemints',function(){
		return function(input){
		var meridiem = input.match(/[a-zA-Z]+|[0-9]+/g)[0];
		return Number(meridiem);
		}
});
equipmentPointApp.filter('convtimestamp',function(){
		return function(input){
		var arr_var = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
		input = input.split("/");
		var year = input[2].slice(2,4);
		return arr_var[input[0]-1]+''+year;
		}
});
equipmentPointApp.filter('splitData',function(){
		return function(input){
		input = input.slice(0,3);
		return input;
		}
});
equipmentPointApp.filter('onlyday',function(){
		return function(input){
		input = input.split('/')[1];
		return input;
		}
});
